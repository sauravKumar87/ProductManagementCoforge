import { Component, AfterViewInit, Input } from '@angular/core';
import { User } from './User';
import { Router } from '@angular/router';
@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit {
	AfterViewInit(){

	}
	ngAfterViewInit(): void{}

	@Input() user: User;

	ngSubmit(){
		if(this.user.username=='')
		this.router.navigate(['detail']);
	}

	constructor( private router: Router) {
		this.user = new User();
	}

}
