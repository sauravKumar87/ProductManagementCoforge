export class User{

    username:string;
    password:string;
    role:string;
  constructor(){
    this.username='';
    this.password='';
    this.role='';
  }

} 