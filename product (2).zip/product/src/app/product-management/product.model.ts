export interface Product {
    id: number;
    name: string;
    price: number;
    // Add other properties as needed
  }
  