import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Product } from './product.model'; // Import the Product model

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  private products: Product[] = []; // You can initialize with mock data or fetch from API

  getProducts(): Observable<Product[]> {
    return of(this.products);
  }

  addProduct(newProduct: Product): Observable<Product> {
    // Simulate generating a unique ID (you might have a more appropriate way to do this)
    const id = this.products.length > 0 ? Math.max(...this.products.map(product => product.id)) + 1 : 1;

    newProduct.id = id;
    this.products.push(newProduct);

    return of(newProduct);
  }

  updateProduct(updatedProduct: Product): Observable<Product> {
    const index = this.products.findIndex(product => product.id === updatedProduct.id);

    if (index !== -1) {
      this.products[index] = updatedProduct;
    }

    return of(updatedProduct);
  }

  deleteProduct(productId: number): Observable<void> {
    const index = this.products.findIndex(product => product.id === productId);

    if (index !== -1) {
      this.products.splice(index, 1);
    }

    return of();
  }
}
