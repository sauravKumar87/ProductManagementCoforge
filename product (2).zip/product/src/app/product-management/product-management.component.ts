import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service'; // Update this path
import { Product } from './product.model'; // Update this path

@Component({
  selector: 'app-product-management',
  templateUrl: './product-management.component.html',
  styleUrls: ['./product-management.component.scss']
})
export class ProductManagementComponent implements OnInit {
  newProduct: Product = { id: 0, name: '', price: 0 };
  products: Product[] = [];
  selectedProduct: Product | null = null;

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe((products: Product[]) => {
      this.products = products;
    });
  }

  addProduct(): void {
    this.productService.addProduct(this.newProduct).subscribe((addedProduct: Product) => {
      this.products.push(addedProduct);
      this.newProduct = { id: 0, name: '', price: 0 }; // Reset the newProduct object
    });
  }
  deleteProduct(productId: number): void {
    this.productService.deleteProduct(productId).subscribe(() => {
      this.products = this.products.filter(product => product.id !== productId);
      if (this.selectedProduct?.id === productId) {
        this.selectedProduct = null;
      }
    });
  }
  

  
  showUpdateForm(product: Product): void {
    this.selectedProduct = { ...product };
  }
  

  updateProduct(): void {
    if (this.selectedProduct) {
      this.productService.updateProduct(this.selectedProduct).subscribe(updatedProduct => {
        const index = this.products.findIndex(product => product.id === updatedProduct.id);
        if (index !== -1) {
          this.products[index] = updatedProduct;
          this.selectedProduct = null; // Clear the selectedProduct after update
        }
      });
    }
  }
  
}
