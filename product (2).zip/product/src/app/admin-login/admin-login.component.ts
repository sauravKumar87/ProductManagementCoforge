import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login() {
    // Implement your authentication logic here.
    // For demonstration purposes, you can assume successful login for now.
    // In a real application, you'd validate credentials and handle the result.
    
    // After successful login, navigate to the product management page.
    this.router.navigate(['/product-management']);
  }
}
